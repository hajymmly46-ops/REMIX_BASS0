// آهنگ‌های خودت را اینجا اضافه کن. فایل‌ها را داخل پوشه assets قرار بده.
const tracks = [
  // نمونه:
  // { title: "نام ریمیکس", artist: "نام دی‌جی", category: "ریمیکس", file: "assets/remix.mp3" }
];
const channelUrl = "https://t.me/REMIX_BASS0";
const songsEl = document.getElementById("songs");
const emptyEl = document.getElementById("empty");
const searchEl = document.getElementById("search");
const gate = document.getElementById("gate");
let selectedTrack = null;
let currentFilter = "همه";

function render() {
  const q = searchEl.value.trim().toLowerCase();
  const shown = tracks.filter(t =>
    (currentFilter === "همه" || t.category === currentFilter) &&
    (t.title + " " + t.artist).toLowerCase().includes(q)
  );
  document.getElementById("songCount").textContent = `${shown.length} آهنگ`;
  songsEl.innerHTML = shown.map((t, i) => `
    <article class="song">
      <div class="cover">♫</div>
      <div class="song-info"><strong>${escapeHtml(t.title)}</strong><small>${escapeHtml(t.artist)} • ${escapeHtml(t.category)}</small></div>
      <button class="download" data-index="${tracks.indexOf(t)}">دانلود ⬇</button>
    </article>`).join("");
  emptyEl.style.display = shown.length ? "none" : "block";
}
function escapeHtml(s) {
  return String(s).replace(/[&<>"']/g, c => ({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#39;"}[c]));
}
songsEl.addEventListener("click", e => {
  const btn = e.target.closest("[data-index]");
  if (!btn) return;
  selectedTrack = tracks[Number(btn.dataset.index)];
  gate.classList.add("show");
  gate.setAttribute("aria-hidden", "false");
});
document.getElementById("joinLink").href = channelUrl;
document.getElementById("continueDownload").addEventListener("click", () => {
  if (!selectedTrack) return;
  // بعد از بازدید کانال، دانلود در همان صفحه با کلیک کاربر آغاز می‌شود.
  const a = document.createElement("a");
  a.href = selectedTrack.file;
  a.download = "";
  document.body.appendChild(a); a.click(); a.remove();
  gate.classList.remove("show"); gate.setAttribute("aria-hidden", "true");
});
function closeGate(){ gate.classList.remove("show"); gate.setAttribute("aria-hidden", "true"); }
document.getElementById("closeGate").addEventListener("click", closeGate);
searchEl.addEventListener("input", render);
document.querySelectorAll(".chip").forEach(btn => btn.addEventListener("click", () => {
  document.querySelector(".chip.active")?.classList.remove("active");
  btn.classList.add("active"); currentFilter = btn.dataset.filter; render();
}));
render();
